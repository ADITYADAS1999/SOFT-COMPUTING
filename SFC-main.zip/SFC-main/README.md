# SFC
Course: Soft Computing
Project name: Demonstration of learning with backpropagation - simple algorithm + chosen optimizer.
<br>
Academic year: 2022/2023<br>
Author: Richard Klem<br>
E-mail: xklemr00@stud.fit.vutbr.cz<br>
Date: 27th November 2022<br>

# About
Adam, AmsGrad and none are option you can select.<br>
Approach inspiration was taken from https://github.com/sgugger/Deep-Learning

# Run
Run the script `run.sh`.<br>
If it fails, enter each line at the time of that script manually.

# Data licensing
Usage of compressed or other data present in this repository must follow proper related licenses.
