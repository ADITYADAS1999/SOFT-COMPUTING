tar -xf .data.tar.xz
python3 -m venv xklemr00
. xklemr00/bin/activate
python3 -m pip install -r requirements.txt
python3 mainwindow.py