# Soft-Computing-Lab
Lab experiments on Neural Networks for Undergraduate ECE Students , NIT Rourkela
